<!-- mytestmail.blade.php -->

<h1>Hello!</h1>
<p>This is a test email.</p>
<?php /**PATH C:\xampp\htdocs\workonit\resources\views/mytestmail.blade.php ENDPATH**/ ?>