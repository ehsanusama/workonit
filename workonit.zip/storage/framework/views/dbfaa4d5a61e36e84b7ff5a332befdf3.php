<div id="embed_chatbot_container_id" style="height: 462px">
    <script src="https://www.uchat.com.au/js/widget/ve4cwaxxkhqj6ivg/embed.js?id=embed_chatbot_container_id"></script>
</div><?php /**PATH C:\xampp\htdocs\workonit\resources\views/chatbot.blade.php ENDPATH**/ ?>