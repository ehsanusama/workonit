<!-- mytestmail.blade.php -->

<h1>Hello!</h1>
<p>This is a test email.</p>
